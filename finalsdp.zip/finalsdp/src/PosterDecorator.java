class PosterDecorator implements Poster {
    private Poster poster;
    private String author;
    private String comment;

    public PosterDecorator(Poster poster, String author, String comment) {
        this.poster = poster;
        this.author = author;
        this.comment = comment;
    }

    @Override
    public void display() {
        poster.display();
        System.out.println("Author: " + author);
        System.out.println("Comment: " + comment);
    }
}

