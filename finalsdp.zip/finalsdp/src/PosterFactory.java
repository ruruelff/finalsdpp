class PosterFactory {
    public Poster createPoster(String name) {
        return new ConcretePoster(name);
    }
}


