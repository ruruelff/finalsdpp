import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class PosterCollection {
    private static PosterCollection instance;

    private List<Poster> posters = new ArrayList<>();
    private List<String> collectedPosterNames = new ArrayList<>();
    private List<String> posterHistory = new ArrayList<>();

    private PosterCollection() {
        // Private constructor to prevent instantiation
    }

    public static PosterCollection getInstance() {
        if (instance == null) {
            instance = new PosterCollection();
        }
        return instance;
    }

    public void addPoster(Poster poster) {
        posters.add(poster);
        collectedPosterNames.add(((ConcretePoster) poster).getName());
        posterHistory.add("Added: " + ((ConcretePoster) poster).getName());
    }

    public void deletePoster(String posterName) {
        for (Poster poster : posters) {
            if (((ConcretePoster) poster).getName().equalsIgnoreCase(posterName)) {
                posters.remove(poster);
                collectedPosterNames.remove(posterName);
                posterHistory.add("Deleted: " + posterName);
                return;
            }
        }
        System.out.println("Poster not found: " + posterName);
        posterHistory.add("Attempted to delete: " + posterName + " (not found)");
    }

    public void displayAllPosters() {
        for (Poster poster : posters) {
            poster.display();
            System.out.println("-----");
        }
    }

    public void displayCollectedPosterNames() {
        System.out.println("Collected Movie Posters:");
        for (String posterName : collectedPosterNames) {
            System.out.println(posterName);
        }
    }

    public void displayPosterHistory() {
        System.out.println("Poster Collection History:");
        for (String historyItem : posterHistory) {
            System.out.println(historyItem);
        }
    }
}