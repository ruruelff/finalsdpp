class BasicCollectionStrategy implements PosterCollectionStrategy {
    @Override
    public void collect(Poster poster) {
        System.out.println("Basic collection strategy: Adding poster to the collection.");
        PosterCollection.getInstance().addPoster(poster);
    }
}
