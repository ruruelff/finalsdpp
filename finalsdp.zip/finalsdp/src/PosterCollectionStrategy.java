interface PosterCollectionStrategy {
    void collect(Poster poster);
}
