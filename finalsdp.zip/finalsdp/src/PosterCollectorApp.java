import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class PosterCollectorApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Using the observer pattern to notify collectors
        PosterCollector collector1 = new PosterCollector("Collector 1");
        PosterCollector collector2 = new PosterCollector("Collector 2");

        java.util.Observable observable = new java.util.Observable();
        observable.addObserver(collector1);
        observable.addObserver(collector2);

        // Using the strategy pattern for collecting posters
        PosterCollectionStrategy basicStrategy = new BasicCollectionStrategy();
        PosterCollectionStrategy advancedStrategy = new AdvancedCollectionStrategy();

        while (true) {
            System.out.println("\nOptions:");
            System.out.println("1. Add a new poster");
            System.out.println("2. Delete a poster");
            System.out.println("3. Show collected poster names");
            System.out.println("4. Show poster collection history");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5): ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    System.out.print("Enter the name of the movie poster: ");
                    String posterName = scanner.nextLine();
                    PosterFactory posterFactory = new PosterFactory();
                    Poster poster = posterFactory.createPoster(posterName);
                    observable.notifyObservers("New poster added: " + posterName);
                    System.out.print("Choose collection strategy (basic/advanced): ");
                    String strategyType = scanner.nextLine();
                    if (strategyType.equalsIgnoreCase("basic")) {
                        basicStrategy.collect(poster);
                    } else if (strategyType.equalsIgnoreCase("advanced")) {
                        advancedStrategy.collect(poster);
                    } else {
                        System.out.println("Invalid strategy. Using basic strategy by default.");
                        basicStrategy.collect(poster);
                    }
                    break;
                case 2:
                    System.out.print("Enter the name of the movie poster to delete: ");
                    String posterToDelete = scanner.nextLine();
                    PosterCollection.getInstance().deletePoster(posterToDelete);
                    break;
                case 3:
                    PosterCollection.getInstance().displayCollectedPosterNames();
                    break;
                case 4:
                    PosterCollection.getInstance().displayPosterHistory();
                    break;
                case 5:
                    System.out.println("Exiting the program.");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please choose a valid option.");
            }
        }
    }
}