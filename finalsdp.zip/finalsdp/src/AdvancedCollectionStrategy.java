import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class AdvancedCollectionStrategy implements PosterCollectionStrategy {
    @Override
    public void collect(Poster poster) {
        System.out.println("Advanced collection strategy: Enhancing and then adding the poster to the collection.");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author for the poster: ");
        String author = scanner.nextLine();
        System.out.print("Enter comment for the poster: ");
        String comment = scanner.nextLine();
        PosterDecorator decoratedPoster = new PosterDecorator(poster, author, comment);
        PosterCollection.getInstance().addPoster(decoratedPoster);
    }
}
