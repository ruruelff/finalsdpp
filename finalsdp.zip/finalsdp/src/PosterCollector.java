class PosterCollector implements java.util.Observer {
    private String collectorName;

    public PosterCollector(String collectorName) {
        this.collectorName = collectorName;
    }

    @Override
    public void update(java.util.Observable o, Object arg) {
        System.out.println(collectorName + " has received an update: " + arg);
    }
}
