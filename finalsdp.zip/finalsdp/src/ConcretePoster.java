class ConcretePoster implements Poster {
    private String name;

    public ConcretePoster(String name) {
        this.name = name;
    }

    @Override
    public void display() {
        System.out.println("Displaying poster: " + name);
    }

    public String getName() {
        return name;
    }
}