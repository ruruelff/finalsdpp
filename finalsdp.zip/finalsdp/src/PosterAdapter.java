class PosterAdapter implements Poster {
    private ConcretePoster concretePoster;

    public PosterAdapter(ConcretePoster concretePoster) {
        this.concretePoster = concretePoster;
    }

    @Override
    public void display() {
        concretePoster.display();
    }

    // Additional method to adapt the format
    public void adaptFormat() {
        System.out.println("Adapting poster format");
    }
}

