interface Poster {
    void display();
}
